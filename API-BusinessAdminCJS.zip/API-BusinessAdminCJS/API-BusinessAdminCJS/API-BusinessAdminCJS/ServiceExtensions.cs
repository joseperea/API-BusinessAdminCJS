﻿namespace API_BusinessAdminCJS
{
    public static class ServiceExtensions
    {

    }
}
