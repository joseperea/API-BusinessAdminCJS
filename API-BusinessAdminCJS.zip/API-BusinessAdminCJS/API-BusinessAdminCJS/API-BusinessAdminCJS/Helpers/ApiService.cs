﻿using API_BusinessAdminCJS.ModelsView;
using Newtonsoft.Json;

namespace API_BusinessAdminCJS.Helpers
{
    public class ApiService : IApiService
    {
        private readonly IConfiguration _configuration;
        private readonly string _urlBase;
        private readonly string _tokenName;
        private readonly string _tokenValue;

        public ApiService(IConfiguration configuration)
        {
            _configuration = configuration;
            _urlBase = _configuration["CoutriesAPI:urlBase"];
            _tokenName = _configuration["CoutriesAPI:tokenName"];
            _tokenValue = _configuration["CoutriesAPI:tokenValue"];
        }

        public async Task<Response> GetListAsync<T>(string servicePrefix, string controller)
        {
            try
            {
                HttpClient client = new()
                {
                    BaseAddress = new Uri(_urlBase),
                };

                client.DefaultRequestHeaders.Add(_tokenName, _tokenValue);
                string url = $"{servicePrefix}{controller}";
                HttpResponseMessage response = await client.GetAsync(url);
                string result = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    return new Response
                    {
                        Error = true,
                        Mensaje = result,
                    };
                }

                List<T> list = JsonConvert.DeserializeObject<List<T>>(result);
                return new Response
                {
                    Error = false,
                    Resultado = list
                };
            }
            catch (Exception ex)
            {
                return new Response
                {
                    Error = true,
                    Mensaje = ex.Message
                };
            }
        }
    }
}
