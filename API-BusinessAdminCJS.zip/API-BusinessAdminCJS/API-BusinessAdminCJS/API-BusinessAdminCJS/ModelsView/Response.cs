﻿namespace API_BusinessAdminCJS.ModelsView
{
    public class Response
    {
        public bool Error { get; set; }

        public string Mensaje { get; set; }

        public object Resultado { get; set; }
    }
}
