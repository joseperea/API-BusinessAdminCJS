﻿using Desk_BusinessAdminCJS.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desk_BusinessAdminCJS.Data
{
    public class DataContext : DbContext
    {

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite(ConfigurationManager.ConnectionStrings["DataContextSQlite"].ConnectionString);
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UnitMeasure>().HasIndex(c => c.UnitMeasureCode).IsUnique();
            modelBuilder.Entity<Mark>().HasIndex(c => c.MarkCode).IsUnique();
            modelBuilder.Entity<Category>().HasIndex(c => c.CategoryCode).IsUnique();
            modelBuilder.Entity<SubCategory>().HasIndex(c => c.SubCategoryCode).IsUnique();
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<Product> Product { get; set; }
        public DbSet<Category> Category { get; set; }
        public DbSet<SubCategory> SubCategory { get; set; }
        public DbSet<Mark> Mark { get; set; }
        public DbSet<ProductProvider> ProductProvider { get; set; }
        public DbSet<Stock> Stock { get; set; }
        public DbSet<Provider> Provider { get; set; }
        public DbSet<UnitMeasure> UnitMeasure { get; set; }
    }
}
