﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desk_BusinessAdminCJS.Data.Entities
{
    public class BaseData
    {
        public int Id { get; set; }
        [Display(Name = "Fecha Creación")]
        public DateTime CreationDate { get; set; }
        [Display(Name = "Fecha Actualización")]
        public DateTime DateUpdate { get; set; }
        [Display(Name = "Estado")]
        public bool State { get; set; }
    }
}
