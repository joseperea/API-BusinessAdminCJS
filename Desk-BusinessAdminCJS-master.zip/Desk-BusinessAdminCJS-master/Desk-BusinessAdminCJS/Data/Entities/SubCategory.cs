﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desk_BusinessAdminCJS.Data.Entities
{
    public class SubCategory : BaseData
    {
        [ForeignKey(nameof(Category))]
        public int CategoryId { get; set; }
        [Display(Name = "Categorí")]
        public string Categori => $"{Category.Name} ({Category.CategoryCode})";

        [Required(ErrorMessage = "Por favor ingresar {0}")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Por favor ingresar {0}")]
        [Display(Name = "Descripción")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Por favor ingresar {0}")]
        [Display(Name = "Codigo")]
        public string SubCategoryCode { get; set; }
        [Display(Name = "Codigo Barras")]
        public string AlternativeBarcode => $"{Category.CategoryCode}{SubCategoryCode}";


        //Relaciones 
        public virtual Category Category { get; set; }

    }
}
