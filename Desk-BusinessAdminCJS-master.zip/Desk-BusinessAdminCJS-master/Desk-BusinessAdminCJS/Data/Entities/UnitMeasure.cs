﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desk_BusinessAdminCJS.Data.Entities
{
    public class UnitMeasure : BaseData
    {
        [Required(ErrorMessage = "Por favor ingresar {0}")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Por favor ingresar {0}")]
        [Display(Name = "Descripción")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Por favor ingresar {0}")]
        [Display(Name = "Código")]
        public string UnitMeasureCode { get; set; }
        public string ClassName { get; set; }
    }
}
