﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Desk_BusinessAdminCJS.Data.Entities
{
    public class Product : BaseData
    {
        [Display(Name = "Unidad de Medida")]
        [Required(ErrorMessage = "Por favor seleccionar la {0}")]
        [ForeignKey(nameof(UnitMeasure))]
        public int UnitMeasureId { get; set; }
        [Display(Name = "Sub Categotía")]
        [Required(ErrorMessage = "Por favor seleccionar la {0}")]
        [ForeignKey(nameof(SubCategory))]
        public int SubCategoryId { get; set; }
        [Display(Name = "Marca")]
        [Required(ErrorMessage = "Por favor seleccionar la {0}")]
        [ForeignKey(nameof(Mark))]
        public int MarkId { get; set; }
        [Required(ErrorMessage = "Por favor ingresar el {0}")]
        [Display(Name = "Nombre Producto")]
        [DataType(DataType.Text)]
        [StringLength(50, ErrorMessage = "Por favor ingresar una de caracteres entre {2} y {1} en el campo {0}", MinimumLength = 3)]
        public string Name { get; set; }
        [Required(ErrorMessage = "Por favor ingresar la {0}")]
        [Display(Name = "Descripción Producto")]
        [DataType(DataType.Text)]
        [StringLength(100, ErrorMessage = "Por favor ingresar una de caracteres entre {2} y {1} en el campo {0}", MinimumLength = 3)]
        public string Description { get; set; }
        [Required(ErrorMessage = "Por favor ingresar el {0}")]
        [Display(Name = "Código Producto")]
        [DataType(DataType.PhoneNumber)]
        [StringLength(4, ErrorMessage = "Por favor ingresar una de caracteres entre {2} y {1} en el campo {0}", MinimumLength = 1)]
        public string ProductCode { get; set; }
        [Display(Name = "Código Barra Producto")]
        public string Barcode { get; set; }
       
        [Display(Name = "Código Barra Alternativo")]
        public string AlternativeBarcode => $"{Mark.MarkCode}{SubCategory.AlternativeBarcode}{UnitMeasure.UnitMeasureCode}{ProductCode}";
        [Required(ErrorMessage = "Por favor ingresar el {0}")]
        [Display(Name = "Precio Compra")]
        [DataType(DataType.Currency)]
        public decimal PriceBuy { get; set; }
        [Required(ErrorMessage = "Por favor ingresar el {0}")]
        [Display(Name = "Porcentaje de Venta")]
        [DataType(DataType.Currency)]
        public decimal SalePercentage { get; set; }
        [Display(Name = "Imgen")]
        [DataType(DataType.ImageUrl)]
        public string image { get; set; }

        //Relaciones
        public virtual UnitMeasure UnitMeasure { get; set; }
        public virtual SubCategory SubCategory { get; set; }
        public virtual Mark Mark { get; set; }
    }
}
