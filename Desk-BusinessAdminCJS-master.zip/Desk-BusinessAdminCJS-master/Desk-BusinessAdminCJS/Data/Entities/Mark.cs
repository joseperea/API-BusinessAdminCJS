﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desk_BusinessAdminCJS.Data.Entities
{
    public class Mark : BaseData
    {
        [Required(ErrorMessage = "Por favor ingresar {0}")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Por favor ingresar {0}")]
        [Display(Name = "Descripción")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Por favor ingresar {0}")]
        [Display(Name = "Codigo")]
        public string MarkCode { get; set; }
    }
}
