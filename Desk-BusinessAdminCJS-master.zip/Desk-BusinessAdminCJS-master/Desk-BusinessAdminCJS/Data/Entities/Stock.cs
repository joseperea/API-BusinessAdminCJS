﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desk_BusinessAdminCJS.Data.Entities
{
    public class Stock : BaseData
    {
        [ForeignKey(nameof(Product))]
        public int ProductId { get; set; }
        public int quantityBuy { get; set; }
        public int quantitySale { get; set; }
        public int Totalquantity => (quantityBuy - quantitySale);
        public DateTime ExpirationDate { get; set; }

        //Relaciones
        public virtual Product Product { get; set; }
    }
}
