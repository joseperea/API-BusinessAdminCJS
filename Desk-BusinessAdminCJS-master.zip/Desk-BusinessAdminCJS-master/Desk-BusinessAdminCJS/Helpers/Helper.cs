﻿using Desk_BusinessAdminCJS.Data.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.IO.Compression;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desk_BusinessAdminCJS.Helpers
{
    public class Helper
    {
        public static string _rutaInicioAplicacion;
        public DataGridView loadListDataGrid<T>(DataGridView dataGrid, List<T> list, bool btnEliminar = true, bool btnEditar = true)
        {
            try
            {
                if (list == null)
                    throw new Exception("Por favor enviar una lista de objectos.");

                if (list.Count < 1)
                    throw new Exception("La lista enviada se encuentra vacia");

                List<string> listNoColumn = new List<string>();
                foreach (var item in list.FirstOrDefault().GetType().GetProperties())
                {
                    if (dataGrid.Columns.Count > 0)
                        if (dataGrid.Columns.Contains(item.Name))
                            continue;

                    if (new string[] { "Desk_BusinessAdminCJS.Data.Entities"}.Any(t => item.PropertyType.ToString().Contains(t)))
                        continue;

                    DataGridViewColumn column = new DataGridViewColumn();
                    column.Name = item.Name;
                    column.HeaderText = ObtenerDisplayAttribute(list[0], item.Name);
                    if (new string[] { "id", "ClassName" }.Any(t => item.Name.ToLower().Contains(t.ToLower()))) 
                        column.Visible = false;

                    //column.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    DataGridViewCell dgvcell = new DataGridViewTextBoxCell();
                    column.CellTemplate = dgvcell;
                    dataGrid.Columns.Add(column);
                }


                for (int i = 0; i < list.Count; i++)
                {

                    DataGridViewRow dataGridViewRow = dataGrid.Rows[dataGrid.Rows.Add()];
                    int coutCell = 0;
                    foreach (var item in list.FirstOrDefault().GetType().GetProperties())
                    {
                        if (new string[] { "Desk_BusinessAdminCJS.Data.Entities" }.Any(t => item.PropertyType.ToString().Contains(t)))
                            continue;

                        dynamic valor = list[i].GetType().GetProperty(item.Name).GetValue(list[i]);
                        //dataGrid.Rows[i].Cells[coutCell].Value = valor;

                        if (new string[] { "State" }.Any(t => t.ToLower() == item.Name.ToLower()))
                            valor = valor ? "Activado" : "Desactivado";

                        dataGridViewRow.Cells[item.Name].Value = valor;
                        coutCell++;
                    }
                    //dataGrid.Rows.Add(dataGridViewRow);
                }

                if (btnEditar)
                {
                    if (!dataGrid.Columns.Contains("Editar"))
                    {
                        DataGridViewImageColumn img = new DataGridViewImageColumn();
                        //Image image = Image.FromFile(Path.Combine(_rutaInicioAplicacion, "Resources", "edit.png"));
                        img.Image = Properties.Resources.edit;
                        img.HeaderText = "Editar";
                        img.Name = "Editar";
                        img.ToolTipText = "Editar";

                        //img.Text = "Editar";
                        //img.UseColumnTextForButtonValue = true;
                        //img.DataPropertyName = "Edit";
                        dataGrid.Columns.Add(img);
                    }
                }

                if (btnEliminar)
                {
                    if (!dataGrid.Columns.Contains("Eliminar"))
                    {
                        DataGridViewImageColumn img = new DataGridViewImageColumn();
                        //Image image = Image.FromFile(Path.Combine(_rutaInicioAplicacion, "Resources", "delete.png"));
                        img.Image = Properties.Resources.delete;
                        img.HeaderText = "Eliminar";
                        img.Name = "Eliminar";
                        img.ToolTipText = "Eliminar";
                        dataGrid.Columns.Add(img);
                    }
                }
                return dataGrid;

            }
            catch (Exception ex)
            {
                throw new Exception($"Error {nameof(loadListDataGrid)}:{Environment.NewLine}{ex.Message}");
            }
        }


        public ComboBox loadListComboBox<T>(ComboBox comboBox, List<T> list, string nombreCombo, bool autoComplete = false, string columnaId = "Id", string columnaValor = "Name")
        {
            try
            {
                if (list == null)
                    throw new Exception("Por favor enviar una lista de objectos.");


                if (list.Count < 1)
                    throw new Exception("La lista enviada se encuentra vacia");

                comboBox.DisplayMember = columnaValor;
                comboBox.ValueMember = columnaId;
                comboBox.DataSource = list;
                if (autoComplete)
                {
                    AutoCompleteStringCollection AutoComplete = new AutoCompleteStringCollection();
                    for (int i = 0; i < list.Count; i++)
                    {
                        foreach (var item in list.FirstOrDefault().GetType().GetProperties())
                        {
                            if (new string[] { "Desk_BusinessAdminCJS.Data.Entities" }.Any(t => item.PropertyType.ToString().Contains(t)))
                                continue;

                            if (item.Name == columnaValor)
                            {
                                dynamic valor = list[i].GetType().GetProperty(item.Name).GetValue(list[i]);
                                AutoComplete.Add(valor);
                                break;
                            }
                        }
                    }
                    AutoComplete.Add($"--- Seleccionar {nombreCombo} ---");

                    comboBox.AutoCompleteCustomSource = AutoComplete;
                    comboBox.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    comboBox.AutoCompleteMode = AutoCompleteMode.Suggest;
                }

                return comboBox;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error {nameof(loadListComboBox)}:{Environment.NewLine}{ex.Message}");
            }
        }

        public bool ValidarObjecto<T>(T objecto)
        {
            try
            {
                List<string> ltsMensajes = new List<string>();
                IList<ValidationResult> errors = new List<ValidationResult>();

                if (!Validator.TryValidateObject(objecto, new ValidationContext(objecto), errors, true))
                    ltsMensajes.AddRange(errors.Select(t => $"* {t.ErrorMessage}"));

                foreach (var item in objecto.GetType().GetProperties())
                {
                    if (new Type[] { typeof(int), typeof(double), typeof(decimal) }.Any(t => t == item.PropertyType) && item.Name.ToLower() != "id")
                    {
                        dynamic valor;
                        valor = Convert.ChangeType(item.GetValue(objecto), item.PropertyType);

                        string displayName = ObtenerDisplayAttribute(objecto, item.Name);
                        if (string.IsNullOrEmpty(displayName))
                            displayName = item.Name;

                        if (valor < 1)
                            ltsMensajes.Add($"* Por favor ingresar la {displayName}");
                    }
                }

                if (ltsMensajes.Count > 0)
                    throw new Exception(string.Join(Environment.NewLine, ltsMensajes));

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error {nameof(ValidarObjecto)}:{Environment.NewLine}{ex.Message}");
            }
        }

        public string ObtenerDisplayAttribute<T>(T objecto, string nombreProperty)
        {
            try
            {
                string displayName = null;
                CustomAttributeData displayAttribute = objecto.GetType().GetProperty(nombreProperty).CustomAttributes.FirstOrDefault(x => x.AttributeType.Name == "DisplayAttribute");
                if (displayAttribute != null)
                    displayName = displayAttribute.NamedArguments.FirstOrDefault().TypedValue.Value.ToString();

                return displayName;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error {nameof(ObtenerDisplayAttribute)}:{Environment.NewLine}{ex.Message}");
            }
        }

        public T MapearDataGridRowObjeto<T>(T objecto, DataGridViewRow dataGridViewRow)
        {
            try
            {
                foreach (var item in objecto.GetType().GetProperties())
                {
                    if (new string[] { "Desk_BusinessAdminCJS.Data.Entities" }.Any(t => item.PropertyType.ToString().Contains(t)))
                        continue;

                    dynamic valor = dataGridViewRow.Cells[item.Name].Value;

                    if (new string[] { "State" }.Any(t => t.ToLower() == item.Name.ToLower()))
                        valor = valor == "Activado" ? true : false;

                    valor = Convert.ChangeType(valor, item.PropertyType);

                    if (item.SetMethod != null)
                        item.SetValue(objecto, valor);
                    
                }

                return objecto;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
 
        }

        public string ConvertirBase64(string pathImage)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(pathImage))
                    throw new Exception("La ruta de la imagen no puede estar nula o vacía.");

                if (!File.Exists(pathImage))
                    throw new Exception(string.Concat("No existe la imagen en la ruta: ", pathImage));

                byte[] imageArray = System.IO.File.ReadAllBytes(pathImage);
                string strBase64Image = Convert.ToBase64String(imageArray);
                return strBase64Image;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Image Base64ToImage(string base64String)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(base64String))
                    throw new Exception("La imagen en base64 no puede estar nula o vacía.");

                // Convert base 64 string to byte[]
                byte[] imageBytes = Convert.FromBase64String(base64String);
                // Convert byte[] to Image
                using (var ms = new MemoryStream(imageBytes, 0, imageBytes.Length))
                {
                    Image image = Image.FromStream(ms, true);
                    return image;
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public string CompressString(string text)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(text);
            var memoryStream = new MemoryStream();
            using (var gZipStream = new GZipStream(memoryStream, CompressionMode.Compress, true))
            {
                gZipStream.Write(buffer, 0, buffer.Length);
            }

            memoryStream.Position = 0;

            var compressedData = new byte[memoryStream.Length];
            memoryStream.Read(compressedData, 0, compressedData.Length);

            var gZipBuffer = new byte[compressedData.Length + 4];
            Buffer.BlockCopy(compressedData, 0, gZipBuffer, 4, compressedData.Length);
            Buffer.BlockCopy(BitConverter.GetBytes(buffer.Length), 0, gZipBuffer, 0, 4);
            return Convert.ToBase64String(gZipBuffer);
        }

        public string DecompressString(string compressedText)
        {
            byte[] gZipBuffer = Convert.FromBase64String(compressedText);
            using (var memoryStream = new MemoryStream())
            {
                int dataLength = BitConverter.ToInt32(gZipBuffer, 0);
                memoryStream.Write(gZipBuffer, 4, gZipBuffer.Length - 4);

                var buffer = new byte[dataLength];

                memoryStream.Position = 0;
                using (var gZipStream = new GZipStream(memoryStream, CompressionMode.Decompress))
                {
                    gZipStream.Read(buffer, 0, buffer.Length);
                }

                return Encoding.UTF8.GetString(buffer);
            }
        }
    }
}
