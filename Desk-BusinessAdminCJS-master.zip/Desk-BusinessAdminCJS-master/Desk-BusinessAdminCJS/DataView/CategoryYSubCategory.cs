﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desk_BusinessAdminCJS.DataView
{
    public class CategoryYSubCategory
    {
        public int IdCategory { get; set; }
        public int IdSubCategory { get; set; }
        [Display(Name = "Codigo Categoría")]
        public string CodigoCategory { get; set; }
        [Display(Name = "Nombre Categoría")]
        public string NombreCategory { get; set; }
        [Display(Name = "Descripción Categoría")]
        public string DescripcionCategory { get; set; }
        [Display(Name = "Codigo SubCategoría")]
        public string CodigoSubCategory { get; set; }
        [Display(Name = "Nombre SubCategoría")]
        public string NombreSubCategory { get; set; }
        [Display(Name = "Descripción SubCategoría")]
        public string DescripcionSubCategory { get; set; }
        [Display(Name = "Codigo De Barra")]
        public string CodigoBarra { get; set; }
    }
}
