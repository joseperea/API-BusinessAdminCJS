﻿using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using Desk_BusinessAdminCJS.View.UnitMeasures;

namespace Desk_BusinessAdminCJS.View.Marks
{
    public partial class FormListaMark : Form
    {

        private DataContext _dataContext;
        private Helper _helper;
        private List<Mark> _marks;

        public FormListaMark()
        {
            InitializeComponent();
            _dataContext = new DataContext();
            _helper = new Helper();
        }

        private async void FormListaMark_Load(object sender, EventArgs e)
        {
            try
            {
                _marks = await _dataContext.Mark.ToListAsync();
                if (_marks.Count > 0)
                    dgvListMark = _helper.loadListDataGrid<Data.Entities.Mark>(dgvListMark, _marks, false, true);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al iniciar el modulo de lista de marcas");
            }
        }

        private void dgvListMark_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex >= 0)
            {
                if (new string[] { "Editar", "Eliminar" }.Any(t => t == dgvListMark.Columns[e.ColumnIndex].Name))
                    dgvListMark.Cursor = Cursors.Hand;
                else
                    dgvListMark.Cursor = Cursors.Default;
            }
            else
                dgvListMark.Cursor = Cursors.Default;
        }

        private void dgvListMark_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0)
                {
                    _dataContext = new DataContext();
                    if (new string[] { "Editar" }.Any(t => t == dgvListMark.Columns[e.ColumnIndex].Name))
                    {
                        DataGridViewRow dataGridViewRowCollection = dgvListMark.Rows[e.RowIndex];
                        Mark mark = _helper.MapearDataGridRowObjeto(new Mark(), dataGridViewRowCollection);
                        FormAgargeEditarMark formAgargeEditarMark = new FormAgargeEditarMark(mark, false);
                        formAgargeEditarMark.ShowDialog();
                        dgvListMark.Rows.Clear();
                        _marks = _dataContext.Mark.ToList();
                        dgvListMark = _helper.loadListDataGrid(dgvListMark, _marks, false, true);
                    }
                    //else if (new string[] { "Eliminar" }.Any(t => t == dgvListUnitMeasure.Columns[e.ColumnIndex].Name))
                    //{
                    //    DataGridViewRow dataGridViewRowCollection = dgvListUnitMeasure.Rows[e.RowIndex];
                    //    UnitMeasure unitMeasure = _helper.MapearDataGridRowObjeto(new UnitMeasure(), dataGridViewRowCollection);
                    //    string strTitulo = $"{}";
                    //    if (MessageBox.Show("", ""))
                    //    {

                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al editar o eliminar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnNuevo_Click(object sender, EventArgs e)
        {
            try
            {
                FormAgargeEditarMark formAgargeEditarMark = new FormAgargeEditarMark(new Mark(), true);
                formAgargeEditarMark.ShowDialog();
                dgvListMark.Rows.Clear();
                dgvListMark = _helper.loadListDataGrid(dgvListMark, await _dataContext.Mark.ToListAsync(), false, true);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al agregar una nueva marca", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void txtBuscarProducto_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                _marks = await _dataContext.Mark.ToListAsync();
                if (_marks.Count > 0)
                {
                    _marks = _marks.Where(t => t.Name.ToLower().Contains(txtBuscarProducto.Text.ToLower()) || t.Description.ToLower().Contains(txtBuscarProducto.Text.ToLower()) || t.MarkCode.Contains(txtBuscarProducto.Text) || t.MarkCode.Contains(txtBuscarProducto.Text)).ToList();
                    dgvListMark.Rows.Clear();
                    dgvListMark = _helper.loadListDataGrid(dgvListMark, _marks, false, true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro al buscar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
