﻿using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;

namespace Desk_BusinessAdminCJS.View.Marks
{
    public partial class FormAgargeEditarMark : Form
    {
        public Mark _mark;
        public Helper _helper;
        public DataContext _dataContext;
        public bool _Agregar;

        public FormAgargeEditarMark(Mark mark, bool agregar)
        {
            InitializeComponent();
            _mark = mark;
            _helper = new Helper();
            _dataContext = new DataContext();
            _Agregar = agregar;
        }

        private void FormAgargeEditarMark_Load(object sender, EventArgs e)
        {
            try
            {
                if (!_Agregar && _mark != null)
                {
                    if (_mark.Id < 1)
                        throw new Exception("Por favor enviar la información a editar.");

                    txtCodigo.Text = _mark.MarkCode;
                    txtDescripcion.Text = _mark.Description;
                    txtNombre.Text = _mark.Name;
                    cbxState.Text = _mark.State ? "Desactivar" : "Activar";
                    cbxState.Checked = _mark.State;
                    cbxState.Visible = true;
                    Application.DoEvents();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al iniciar el modulo de marca", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAgregarEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (_Agregar)
                    _mark = new Mark();

                _mark.Name = txtNombre.Text;
                _mark.Description = txtDescripcion.Text;
                _mark.MarkCode = txtCodigo.Text.PadLeft(4,'0');

                if (_helper.ValidarObjecto(_mark))
                {
                    _mark.DateUpdate = DateTime.Now;
                    _mark.CreationDate = _Agregar ? DateTime.Now : _mark.CreationDate;
                    _mark.State = _Agregar ? true : cbxState.Checked;

                    if (_Agregar)
                        _dataContext.Add(_mark);
                    else
                        _dataContext.Entry(_mark).State = EntityState.Modified;

                    _dataContext.SaveChanges();
                }
                string strAccion = _Agregar ? "Agregado" : "Actualizado";
                string strTitulo = $"Marca {strAccion} con exito.";
                string strMensaje = $"Se creo la Marca:{Environment.NewLine}{Environment.NewLine}" +
                                    $"Código: {_mark.MarkCode}{Environment.NewLine}" +
                                    $"Nombre: {_mark.Name}{Environment.NewLine}" +
                                    $"Descripción: {_mark.Description}{Environment.NewLine}";
                MessageBox.Show(strMensaje, strTitulo, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.Close();
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                    if (ex.InnerException.Message.Contains("UNIQUE constraint failed"))
                    {
                        MessageBox.Show($"El codigo {_mark.MarkCode} ya existe, por favor validar", "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                MessageBox.Show(ex.Message, "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsDigit(e.KeyChar) && !(e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Delete))
                    e.Handled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al ingresar el código", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbxState_Click(object sender, EventArgs e)
        {
            if (cbxState.Checked)
                cbxState.Text = "Desactivar";
            else
                cbxState.Text = "Activar";
        }
    }
}
