﻿using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;

namespace Desk_BusinessAdminCJS.View.UnitMeasures
{
    public partial class FormAgregarEditarUnidadMedida : Form
    {
        public UnitMeasure _unitMeasure;
        public Helper _helper;
        public DataContext _dataContext;
        public bool _Agregar;

        public FormAgregarEditarUnidadMedida(UnitMeasure unitMeasure, bool agregar )
        {
            InitializeComponent();
            _dataContext = new DataContext();
            _helper = new Helper();
            _unitMeasure = unitMeasure;
            _Agregar = agregar;
        }

        private void FormAgregarUnidadMedida_Load(object sender, EventArgs e)
        {
            try
            {
                if (!_Agregar && _unitMeasure != null)
                {
                    if (_unitMeasure.Id < 1)
                        throw new Exception("Por favor enviar la información a editar.");

                    txtCodigo.Text = _unitMeasure.UnitMeasureCode;
                    txtDescripcion.Text = _unitMeasure.Description;
                    txtNombre.Text = _unitMeasure.Name;
                    cbxState.Text = _unitMeasure.State ? "Desactivar" : "Activar";
                    cbxState.Checked = _unitMeasure.State;
                    cbxState.Visible = true;
                    Application.DoEvents();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al iniciar el modulo de unidad de medida", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAgregarEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (_Agregar)
                    _unitMeasure = new UnitMeasure();

                _unitMeasure.Name = txtNombre.Text;
                _unitMeasure.Description = txtDescripcion.Text;
                _unitMeasure.UnitMeasureCode = txtCodigo.Text.PadLeft(4, '0');

                if (_helper.ValidarObjecto(_unitMeasure))
                {
                    _unitMeasure.DateUpdate = DateTime.Now;
                    _unitMeasure.CreationDate = _Agregar ? DateTime.Now : _unitMeasure.CreationDate;
                    _unitMeasure.ClassName = _Agregar ? string.Empty : _unitMeasure.ClassName;
                    _unitMeasure.State = _Agregar ? true : cbxState.Checked;

                    if (_Agregar)
                        _dataContext.Add(_unitMeasure);
                    else
                        _dataContext.Entry(_unitMeasure).State = EntityState.Modified;

                    _dataContext.SaveChanges();
                }
                string strAccion = _Agregar ? "Agregado" : "Actualizado";
                string strTitulo = $"Unidad de medida {strAccion} con exito.";
                string strMensaje = $"Se creo la unidad de medida:{Environment.NewLine}{Environment.NewLine}" +
                                    $"Código: {_unitMeasure.UnitMeasureCode}{Environment.NewLine}" +
                                    $"Nombre: {_unitMeasure.Name}{Environment.NewLine}" +
                                    $"Descripción: {_unitMeasure.Description}{Environment.NewLine}";
                MessageBox.Show(strMensaje, strTitulo, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.Close();
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                    if (ex.InnerException.Message.Contains("UNIQUE constraint failed")) 
                    {
                        MessageBox.Show($"El codigo {_unitMeasure.UnitMeasureCode} ya existe, por favor validar", "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                MessageBox.Show(ex.Message, "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsDigit(e.KeyChar) && !(e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Delete))
                    e.Handled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al ingresar el código", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbxState_Click(object sender, EventArgs e)
        {
            if (cbxState.Checked)
                cbxState.Text = "Desactivar";
            else
                cbxState.Text = "Activar";
        }
    }
}
