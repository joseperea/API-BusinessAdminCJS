﻿using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Helpers;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desk_BusinessAdminCJS.View.UnitMeasures
{
    public partial class FormlistaUnidadMedida : Form
    {
        private DataContext _dataContext;
        private Helper _helper;
        private List<UnitMeasure> _unitMeasures;
        public FormlistaUnidadMedida()
        {
            InitializeComponent();
            _dataContext = new DataContext();
            _helper = new Helper();
        }

        private async void FormlistaUnidadMedida_Load(object sender, EventArgs e)
        {
            try
            {
                _unitMeasures = await _dataContext.UnitMeasure.ToListAsync();
                if (_unitMeasures.Count > 0)
                    dgvListUnitMeasure = _helper.loadListDataGrid<Data.Entities.UnitMeasure>(dgvListUnitMeasure, _unitMeasures, false, true);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al iniciar el modulo de lista de unidad Medida");
            }
        }

        private void dgvListUnitMeasure_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex >= 0) 
            {
                if (new string[] { "Editar", "Eliminar" }.Any(t => t == dgvListUnitMeasure.Columns[e.ColumnIndex].Name))
                    dgvListUnitMeasure.Cursor = Cursors.Hand;
                else
                    dgvListUnitMeasure.Cursor = Cursors.Default;
            }
            else
                dgvListUnitMeasure.Cursor = Cursors.Default;

        }

        private void dgvListUnitMeasure_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0)
                {
                    _dataContext = new DataContext();
                    if (new string[] { "Editar" }.Any(t => t == dgvListUnitMeasure.Columns[e.ColumnIndex].Name))
                    {
                        DataGridViewRow dataGridViewRowCollection = dgvListUnitMeasure.Rows[e.RowIndex];
                        UnitMeasure unitMeasure = _helper.MapearDataGridRowObjeto(new UnitMeasure(), dataGridViewRowCollection);
                        FormAgregarEditarUnidadMedida formAgregarEditarUnidadMedida = new FormAgregarEditarUnidadMedida(unitMeasure, false);
                        formAgregarEditarUnidadMedida.ShowDialog();
                        dgvListUnitMeasure.Rows.Clear();
                        _unitMeasures = _dataContext.UnitMeasure.ToList();
                        dgvListUnitMeasure = _helper.loadListDataGrid(dgvListUnitMeasure, _unitMeasures, false, true);
                    }
                    //else if (new string[] { "Eliminar" }.Any(t => t == dgvListUnitMeasure.Columns[e.ColumnIndex].Name))
                    //{
                    //    DataGridViewRow dataGridViewRowCollection = dgvListUnitMeasure.Rows[e.RowIndex];
                    //    UnitMeasure unitMeasure = _helper.MapearDataGridRowObjeto(new UnitMeasure(), dataGridViewRowCollection);
                    //    string strTitulo = $"{}";
                    //    if (MessageBox.Show("", ""))
                    //    {

                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al editar o eliminar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private async void btnNuevo_Click(object sender, EventArgs e)
        {
            try
            {
                FormAgregarEditarUnidadMedida formAgregarEditarUnidadMedida = new FormAgregarEditarUnidadMedida(new UnitMeasure(), true);
                formAgregarEditarUnidadMedida.ShowDialog();
                dgvListUnitMeasure.Rows.Clear();
                dgvListUnitMeasure = _helper.loadListDataGrid(dgvListUnitMeasure, await _dataContext.UnitMeasure.ToListAsync(), false, true);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al agregar nueva unidad de medida", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void txtBuscarProducto_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                _unitMeasures = await _dataContext.UnitMeasure.ToListAsync();
                if (_unitMeasures.Count > 0)
                {
                    _unitMeasures = _unitMeasures.Where(t => t.Name.ToLower().Contains(txtBuscarProducto.Text.ToLower()) || t.Description.ToLower().Contains(txtBuscarProducto.Text.ToLower()) || t.UnitMeasureCode.Contains(txtBuscarProducto.Text)).ToList();
                    dgvListUnitMeasure.Rows.Clear();
                    dgvListUnitMeasure = _helper.loadListDataGrid(dgvListUnitMeasure, _unitMeasures, false, true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Erro al buscar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
