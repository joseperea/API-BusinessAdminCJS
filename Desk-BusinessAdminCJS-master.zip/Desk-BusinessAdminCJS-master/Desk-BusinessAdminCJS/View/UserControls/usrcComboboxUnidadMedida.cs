﻿using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Helpers;
using Desk_BusinessAdminCJS.View.UnitMeasures;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desk_BusinessAdminCJS.View.UserControls
{
    public partial class usrcComboboxUnidadMedida : UserControl
    {
        public usrcComboboxUnidadMedida()
        {
            InitializeComponent(); 
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Helper helper = new Helper();
                DataContext dataContext = new DataContext();

                FormAgregarEditarUnidadMedida formAgregarUnidadMedida = new FormAgregarEditarUnidadMedida(null, true);
                formAgregarUnidadMedida.ShowDialog();
                cbxUnitMeasure = helper.loadListComboBox(cbxUnitMeasure, dataContext.UnitMeasure.ToList(), "Unidad de Medida");
                cbxUnitMeasure.Refresh();
                Application.DoEvents();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void usrcComboboxUnidadMedida_Load(object sender, EventArgs e)
        {
            try
            {
                Helper helper = new Helper();
                //cbxUnitMeasure = helper.loadListComboBox(cbxUnitMeasure,new DataContext().UnitMeasure.ToList());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
