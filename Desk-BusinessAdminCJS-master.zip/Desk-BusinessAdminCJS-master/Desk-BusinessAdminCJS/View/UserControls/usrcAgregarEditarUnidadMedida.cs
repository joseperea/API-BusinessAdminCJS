﻿using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desk_BusinessAdminCJS.View.UserControls
{
    public partial class usrcAgregarEditarUnidadMedida : UserControl
    {
        public bool _Agregar;
        public UnitMeasure _unitMeasure;
        public Helper _helper;
        public DataContext _dataContext;
        public Form _form;

        public usrcAgregarEditarUnidadMedida()
        {
            InitializeComponent();
        }

        private void usrcAgregarEditarUnidadMedida_Load(object sender, EventArgs e)
        {
            try
            {
                if (!_Agregar && _unitMeasure != null)
                {
                    if (_unitMeasure.Id < 1)
                        throw new Exception("Por favor enviar la información a editar.");
                    
                    btnAgregarEditar.Text = "Actualizar";
                    txtCodigo.Text = _unitMeasure.UnitMeasureCode;
                    txtDescripcion.Text = _unitMeasure.Description;
                    txtNombre.Text = _unitMeasure.Name;
                }
            }
            catch (Exception ex)
            {
               throw new Exception(ex.Message);
            }
        }

        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsDigit(e.KeyChar) || e.KeyChar != (char)Keys.Back || e.KeyChar != (char)Keys.Delete)
                    e.Handled = true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void btnAgregarEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (_Agregar)
                    _unitMeasure = new UnitMeasure();

                _unitMeasure.Name = txtNombre.Text;
                _unitMeasure.Description = txtDescripcion.Text;
                _unitMeasure.UnitMeasureCode = txtCodigo.Text;

                if (_helper.ValidarObjecto(_unitMeasure))
                {
                    _unitMeasure.DateUpdate = DateTime.Now;
                    _unitMeasure.CreationDate = _Agregar ? DateTime.Now : _unitMeasure.CreationDate;
                    _dataContext.Add(_unitMeasure);
                }
                string strAccion = _Agregar ? "Agregado" : "Actualizado";
                string strTitulo = $"Unidad de medida {strAccion} con exito.";
                string strMensaje = $"Se creo la unidad de medida:{Environment.NewLine}{Environment.NewLine}" +
                                    $"Código: {_unitMeasure.UnitMeasureCode}{Environment.NewLine}"+
                                    $"Nombre: {_unitMeasure.Name}{Environment.NewLine}"+
                                    $"Descripción: {_unitMeasure.Name}{Environment.NewLine}";
                MessageBox.Show(strMensaje, strTitulo, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                _form.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
