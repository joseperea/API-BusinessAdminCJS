﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desk_BusinessAdminCJS.View.UserControls
{
    public partial class usrcSelecionarArchivoImagen : UserControl
    {
        public PictureBox _pictureBox;
        public string _rutaArchivo;
        public usrcSelecionarArchivoImagen()
        {
            InitializeComponent();
        }

        private void btnSelecionarImagen_Click(object sender, EventArgs e)
        {
        
        }

        public PictureBox imagen()
        {
            return _pictureBox;
        }

        public string RutaImagen()
        {
            return _rutaArchivo;
        }

        private void usrcSelecionarArchivoImagen_Load(object sender, EventArgs e)
        {
            // Set the file dialog to filter for graphics files.
            this.openFileDialog1.Filter = "Images (*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|All files (*.*)|*.*";

            // Allow the user to select multiple images.
            this.openFileDialog1.Multiselect = true;
            this.openFileDialog1.Title = "My Image Browser";
        }
    }
}
