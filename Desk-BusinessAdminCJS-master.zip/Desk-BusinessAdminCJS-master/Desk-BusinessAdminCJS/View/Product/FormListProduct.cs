﻿using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desk_BusinessAdminCJS.View.Product
{
    public partial class FormListProduct : Form
    {
        DataContext _DataContext = new DataContext();
        public FormListProduct()
        {
            InitializeComponent();
        }

        private void FormListProduct_Load(object sender, EventArgs e)
        {
            Helpers.Helper helper = new Helpers.Helper();
            //helper.loadListDataGrid<Data.Entities.Product>(dataGridVListaProductos, _DataContext.Product.ToList(), true, true);
        }

        private void btnNuevoProducto_Click(object sender, EventArgs e)
        {
            FormAgregarEditarProducto producto = new FormAgregarEditarProducto(null, true);
            producto.ShowDialog();
        }
    }
}
