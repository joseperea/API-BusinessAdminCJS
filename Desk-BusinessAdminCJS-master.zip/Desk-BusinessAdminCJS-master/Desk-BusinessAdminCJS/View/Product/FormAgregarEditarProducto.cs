﻿using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Helpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic.Devices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desk_BusinessAdminCJS.View.Product
{
    public partial class FormAgregarEditarProducto : Form
    {
        private DataContext _dataContext;
        private Helper _helper;
        private Data.Entities.Product _product;
        private bool _Agregar;
        private List<Mark> _marks;
        private List<UnitMeasure> _unitMeasures;
        private List<Category> _categories;
        private List<SubCategory> _subCategories;
        public FormAgregarEditarProducto(Data.Entities.Product product, bool agregar)
        {
            InitializeComponent();
            _helper = new Helper();
            _dataContext = new DataContext();
            _product = product;
            _Agregar = agregar;
        }

        private void FormAgregarProducto_Load(object sender, EventArgs e)
        {
            try
            {
                this.openFileDialog1.Filter =
            "Images (*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|" +
            "All files (*.*)|*.*";

                // Allow the user to select multiple images.
                //this.openFileDialog1.Multiselect = true;
                this.openFileDialog1.Title = "Mi navegador de imágenes";
                if (!_Agregar)
                    MapeoDatos();

                LoadComboxInical();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al iniciar el modulo de Producto", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();    
            }
  
        }

        private void LoadComboxInical()
        {
            try
            {
                _marks = _dataContext.Mark.ToList();
                _unitMeasures = _dataContext.UnitMeasure.ToList();
                _categories = _dataContext.Category.ToList();

                cbxMark = _helper.loadListComboBox(cbxMark,_marks,"Marca",true);
                cbxUnitMeasure = _helper.loadListComboBox(cbxUnitMeasure, _unitMeasures, "Unidad de Medida", true);
                cbxCategory = _helper.loadListComboBox(cbxCategory, _categories, "Categoria", true);

                cbxMark.SelectedIndex = -1;
                cbxUnitMeasure.SelectedIndex = -1;
                cbxCategory.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void MapeoDatos()
        {
            try
            {
                txtBarcode.Text = _product.Barcode;
                cbxCategory.SelectedValue = _product.SubCategory.CategoryId;
                cbxSubCategory.SelectedValue = _product.SubCategoryId;
                cbxMark.SelectedValue = _product.MarkId;
                cbxUnitMeasure.SelectedValue = _product.UnitMeasureId;
                txtDescription.Text = _product.Description;
                txtName.Text = _product.Name;
                txtPriceBuy.Text = _product.PriceBuy.ToString();
                txtProductCode.Text = _product.ProductCode;
                txtSalePercentage.Text = _product.SalePercentage.ToString();
                Application.DoEvents();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void btnSelecionarImagen_Click(object sender, EventArgs e)
        {
            DialogResult dr = this.openFileDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                // Read the files
                foreach (String file in openFileDialog1.FileNames)
                {
                    // Create a PictureBox.
                    try
                    {
                        PictureBox pb = new PictureBox();
                        ToolTip tt = new ToolTip();
                        Image loadedImage = Image.FromFile(file);
                        pbxImagenProduct.Name = Path.GetFileName(file);
                        pbxImagenProduct.Cursor = Cursors.Hand;
                        pbxImagenProduct.Image = loadedImage;
                        //pbxImagenProduct.Height = tamanoIconLoteria - tamanoYSinLogo;
                        //pbxImagenProduct.Width = tamanoIconLoteria;
                        pbxImagenProduct.SizeMode = PictureBoxSizeMode.StretchImage;
                        tt.SetToolTip(pbxImagenProduct, pbxImagenProduct.Name);

                    }
                    catch (SecurityException ex)
                    {
                        // The user lacks appropriate permissions to read files, discover paths, etc.
                        MessageBox.Show("Security error. Please contact your administrator for details.\n\n" +
                            "Error message: " + ex.Message + "\n\n" +
                            "Details (send to Support):\n\n" + ex.StackTrace
                        );
                    }
                    catch (Exception ex)
                    {
                        // Could not load the image - probably related to Windows file system permissions.
                        MessageBox.Show("Cannot display the image: " + file.Substring(file.LastIndexOf('\\'))
                            + ". You may not have permission to read the file, or " +
                            "it may be corrupt.\n\nReported error: " + ex.Message);
                    }
                }
            }
        }

        private void btnGuardarEditar_Click(object sender, EventArgs e)
        {
            try
            {
                List<string> ltsMensajes = new List<string>();

                if (_Agregar)
                    _product = new Data.Entities.Product();

                _product.Barcode = txtBarcode.Text;
                _product.MarkId = Convert.ToInt32(cbxMark.SelectedValue);
                _product.Mark = _dataContext.Mark.Find(_product.MarkId);
                _product.SubCategoryId = Convert.ToInt32(cbxSubCategory.SelectedValue);
                _product.SubCategory = _dataContext.SubCategory.Find(_product.SubCategoryId);
                _product.UnitMeasureId = Convert.ToInt32(cbxUnitMeasure.SelectedValue);
                _product.UnitMeasure = _dataContext.UnitMeasure.Find(_product.UnitMeasureId);
                _product.CreationDate = _Agregar ? DateTime.Now : _product.CreationDate;
                _product.State = ckbState.Checked;
                _product.Name = txtName.Text;
                _product.DateUpdate = DateTime.Now;
                _product.Description = txtDescription.Text;
                _product.image = _helper.CompressString(_helper.ConvertirBase64(openFileDialog1.FileName));
                _product.PriceBuy = string.IsNullOrWhiteSpace(txtPriceBuy.Text) ? _product.PriceBuy : Convert.ToDecimal(txtPriceBuy.Text);
                _product.ProductCode = txtProductCode.Text;
                _product.SalePercentage = string.IsNullOrWhiteSpace(txtSalePercentage.Text) ? _product.SalePercentage : Convert.ToDecimal(txtSalePercentage.Text);

                if (_helper.ValidarObjecto(_product))
                {

                    //if (!string.IsNullOrWhiteSpace(_product.image))
                    //    if (!File.Exists(_product.image))
                    //        ltsMensajes.Add($"La imagen seleccionada {Path.GetFileName(_product.image)} no existe en la siguiete ruta {Path.GetDirectoryName(_product.image)}");
                    //if (ltsMensajes.Count < 1)
                    //    throw new Exception($"{string.Join(Environment.NewLine, ltsMensajes)}");

                    if (_Agregar) 
                    {
                        _dataContext.Product.Add(_product);

                    }
                    else 
                    {
                        _dataContext.Entry(_product).State = EntityState.Modified;
                    }
                        
                    _dataContext.SaveChanges();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al guardar el producto", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbxCategory_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                int id = Convert.ToInt32(cbxCategory.SelectedValue);
                _subCategories = _dataContext.SubCategory.Where(t => t.CategoryId == id).ToList();
                cbxSubCategory = _helper.loadListComboBox(cbxSubCategory,_subCategories, "SubCategoria",true);
                cbxSubCategory.SelectedIndex = -1;
                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show(ex.Message, "Error al seleccionar la categoria", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtProductCode_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (cbxMark.SelectedIndex < 0 && cbxUnitMeasure.SelectedIndex < 0 && cbxSubCategory.SelectedIndex < 0)
                    return;
                

                Data.Entities.Product product = new Data.Entities.Product
                {
                    ProductCode = txtProductCode.Text.PadLeft(4, '0'),
                    Mark = _marks.FirstOrDefault(t => t.Id == Convert.ToInt32(cbxMark.SelectedValue)),
                    UnitMeasure = _unitMeasures.FirstOrDefault(t => t.Id == Convert.ToInt32(cbxUnitMeasure.SelectedValue)),
                    SubCategory = _subCategories.FirstOrDefault(t => t.Id == Convert.ToInt32(cbxSubCategory.SelectedValue))
                };
                lblAlternativeBarcode.Text = $"{product.AlternativeBarcode}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al agregar el codigo");
            }
        }
    }
}
