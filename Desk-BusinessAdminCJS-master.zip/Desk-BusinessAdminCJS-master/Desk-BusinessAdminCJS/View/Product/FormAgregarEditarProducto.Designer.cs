﻿namespace Desk_BusinessAdminCJS.View.Product
{
    partial class FormAgregarEditarProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxUnitMeasure = new System.Windows.Forms.ComboBox();
            this.lblUnitMeasure = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.cbxCategory = new System.Windows.Forms.ComboBox();
            this.lblSubCategory = new System.Windows.Forms.Label();
            this.cbxSubCategory = new System.Windows.Forms.ComboBox();
            this.lblMark = new System.Windows.Forms.Label();
            this.cbxMark = new System.Windows.Forms.ComboBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblProductCode = new System.Windows.Forms.Label();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.txtBarcode = new System.Windows.Forms.TextBox();
            this.lblPriceBuy = new System.Windows.Forms.Label();
            this.txtPriceBuy = new System.Windows.Forms.TextBox();
            this.lblSalePercentage = new System.Windows.Forms.Label();
            this.txtSalePercentage = new System.Windows.Forms.TextBox();
            this.btnGuardarEditar = new System.Windows.Forms.Button();
            this.ckbState = new System.Windows.Forms.CheckBox();
            this.btnSelecionarImagen = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.lblAlternativeBarcode = new System.Windows.Forms.Label();
            this.pbxImagenProduct = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxImagenProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // cbxUnitMeasure
            // 
            this.cbxUnitMeasure.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cbxUnitMeasure.FormattingEnabled = true;
            this.cbxUnitMeasure.Location = new System.Drawing.Point(12, 95);
            this.cbxUnitMeasure.Name = "cbxUnitMeasure";
            this.cbxUnitMeasure.Size = new System.Drawing.Size(275, 26);
            this.cbxUnitMeasure.TabIndex = 1;
            // 
            // lblUnitMeasure
            // 
            this.lblUnitMeasure.AutoSize = true;
            this.lblUnitMeasure.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblUnitMeasure.Location = new System.Drawing.Point(12, 74);
            this.lblUnitMeasure.Name = "lblUnitMeasure";
            this.lblUnitMeasure.Size = new System.Drawing.Size(219, 18);
            this.lblUnitMeasure.TabIndex = 1;
            this.lblUnitMeasure.Text = "Seleccionar Unidad Medidad :";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCategory.Location = new System.Drawing.Point(12, 132);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(173, 18);
            this.lblCategory.TabIndex = 3;
            this.lblCategory.Text = "Seleccionar Categoría :";
            // 
            // cbxCategory
            // 
            this.cbxCategory.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cbxCategory.FormattingEnabled = true;
            this.cbxCategory.Location = new System.Drawing.Point(12, 153);
            this.cbxCategory.Name = "cbxCategory";
            this.cbxCategory.Size = new System.Drawing.Size(275, 26);
            this.cbxCategory.TabIndex = 2;
            this.cbxCategory.SelectionChangeCommitted += new System.EventHandler(this.cbxCategory_SelectionChangeCommitted);
            // 
            // lblSubCategory
            // 
            this.lblSubCategory.AutoSize = true;
            this.lblSubCategory.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSubCategory.Location = new System.Drawing.Point(12, 189);
            this.lblSubCategory.Name = "lblSubCategory";
            this.lblSubCategory.Size = new System.Drawing.Size(201, 18);
            this.lblSubCategory.TabIndex = 5;
            this.lblSubCategory.Text = "Seleccionar SubCategoría :";
            // 
            // cbxSubCategory
            // 
            this.cbxSubCategory.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cbxSubCategory.FormattingEnabled = true;
            this.cbxSubCategory.Location = new System.Drawing.Point(12, 210);
            this.cbxSubCategory.Name = "cbxSubCategory";
            this.cbxSubCategory.Size = new System.Drawing.Size(275, 26);
            this.cbxSubCategory.TabIndex = 3;
            // 
            // lblMark
            // 
            this.lblMark.AutoSize = true;
            this.lblMark.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblMark.Location = new System.Drawing.Point(12, 15);
            this.lblMark.Name = "lblMark";
            this.lblMark.Size = new System.Drawing.Size(147, 18);
            this.lblMark.TabIndex = 7;
            this.lblMark.Text = "Seleccionar Marca :";
            // 
            // cbxMark
            // 
            this.cbxMark.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cbxMark.FormattingEnabled = true;
            this.cbxMark.Location = new System.Drawing.Point(12, 36);
            this.cbxMark.Name = "cbxMark";
            this.cbxMark.Size = new System.Drawing.Size(275, 26);
            this.cbxMark.TabIndex = 0;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtName.Location = new System.Drawing.Point(318, 37);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(275, 25);
            this.txtName.TabIndex = 5;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblName.Location = new System.Drawing.Point(318, 16);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(141, 18);
            this.lblName.TabIndex = 9;
            this.lblName.Text = "Nombre Producto :";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDescription.Location = new System.Drawing.Point(318, 74);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(170, 18);
            this.lblDescription.TabIndex = 11;
            this.lblDescription.Text = "Descripción Producto :";
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtDescription.Location = new System.Drawing.Point(318, 95);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(275, 25);
            this.txtDescription.TabIndex = 6;
            // 
            // lblProductCode
            // 
            this.lblProductCode.AutoSize = true;
            this.lblProductCode.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblProductCode.Location = new System.Drawing.Point(318, 131);
            this.lblProductCode.Name = "lblProductCode";
            this.lblProductCode.Size = new System.Drawing.Size(136, 18);
            this.lblProductCode.TabIndex = 13;
            this.lblProductCode.Text = "Código Producto :";
            // 
            // txtProductCode
            // 
            this.txtProductCode.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtProductCode.Location = new System.Drawing.Point(318, 152);
            this.txtProductCode.MaxLength = 4;
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(275, 25);
            this.txtProductCode.TabIndex = 7;
            this.txtProductCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtProductCode_KeyUp);
            // 
            // lblBarcode
            // 
            this.lblBarcode.AutoSize = true;
            this.lblBarcode.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblBarcode.Location = new System.Drawing.Point(318, 190);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(179, 18);
            this.lblBarcode.TabIndex = 15;
            this.lblBarcode.Text = "Código Barra Producto :";
            // 
            // txtBarcode
            // 
            this.txtBarcode.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBarcode.Location = new System.Drawing.Point(318, 211);
            this.txtBarcode.Name = "txtBarcode";
            this.txtBarcode.Size = new System.Drawing.Size(275, 25);
            this.txtBarcode.TabIndex = 8;
            // 
            // lblPriceBuy
            // 
            this.lblPriceBuy.AutoSize = true;
            this.lblPriceBuy.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPriceBuy.Location = new System.Drawing.Point(12, 252);
            this.lblPriceBuy.Name = "lblPriceBuy";
            this.lblPriceBuy.Size = new System.Drawing.Size(143, 18);
            this.lblPriceBuy.TabIndex = 18;
            this.lblPriceBuy.Text = "Precio de Compra :";
            // 
            // txtPriceBuy
            // 
            this.txtPriceBuy.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPriceBuy.Location = new System.Drawing.Point(12, 273);
            this.txtPriceBuy.Name = "txtPriceBuy";
            this.txtPriceBuy.Size = new System.Drawing.Size(275, 25);
            this.txtPriceBuy.TabIndex = 10;
            // 
            // lblSalePercentage
            // 
            this.lblSalePercentage.AutoSize = true;
            this.lblSalePercentage.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSalePercentage.Location = new System.Drawing.Point(318, 252);
            this.lblSalePercentage.Name = "lblSalePercentage";
            this.lblSalePercentage.Size = new System.Drawing.Size(158, 18);
            this.lblSalePercentage.TabIndex = 20;
            this.lblSalePercentage.Text = "Porcentaje de Venta :";
            // 
            // txtSalePercentage
            // 
            this.txtSalePercentage.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtSalePercentage.Location = new System.Drawing.Point(318, 273);
            this.txtSalePercentage.Name = "txtSalePercentage";
            this.txtSalePercentage.Size = new System.Drawing.Size(275, 25);
            this.txtSalePercentage.TabIndex = 11;
            // 
            // btnGuardarEditar
            // 
            this.btnGuardarEditar.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnGuardarEditar.Location = new System.Drawing.Point(737, 286);
            this.btnGuardarEditar.Name = "btnGuardarEditar";
            this.btnGuardarEditar.Size = new System.Drawing.Size(101, 23);
            this.btnGuardarEditar.TabIndex = 14;
            this.btnGuardarEditar.Text = "Guardar";
            this.btnGuardarEditar.UseVisualStyleBackColor = true;
            this.btnGuardarEditar.Click += new System.EventHandler(this.btnGuardarEditar_Click);
            // 
            // ckbState
            // 
            this.ckbState.AutoSize = true;
            this.ckbState.Checked = true;
            this.ckbState.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbState.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ckbState.Location = new System.Drawing.Point(711, 208);
            this.ckbState.Name = "ckbState";
            this.ckbState.Size = new System.Drawing.Size(154, 22);
            this.ckbState.TabIndex = 13;
            this.ckbState.Text = "Estado ( inactivo )";
            this.ckbState.UseVisualStyleBackColor = true;
            // 
            // btnSelecionarImagen
            // 
            this.btnSelecionarImagen.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSelecionarImagen.Location = new System.Drawing.Point(697, 171);
            this.btnSelecionarImagen.Name = "btnSelecionarImagen";
            this.btnSelecionarImagen.Size = new System.Drawing.Size(184, 31);
            this.btnSelecionarImagen.TabIndex = 12;
            this.btnSelecionarImagen.Text = "Seleccionar Imagen";
            this.btnSelecionarImagen.UseVisualStyleBackColor = true;
            this.btnSelecionarImagen.Click += new System.EventHandler(this.btnSelecionarImagen_Click);
            // 
            // lblAlternativeBarcode
            // 
            this.lblAlternativeBarcode.AutoSize = true;
            this.lblAlternativeBarcode.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAlternativeBarcode.Location = new System.Drawing.Point(664, 249);
            this.lblAlternativeBarcode.Name = "lblAlternativeBarcode";
            this.lblAlternativeBarcode.Size = new System.Drawing.Size(0, 18);
            this.lblAlternativeBarcode.TabIndex = 25;
            // 
            // pbxImagenProduct
            // 
            this.pbxImagenProduct.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxImagenProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxImagenProduct.Location = new System.Drawing.Point(688, 15);
            this.pbxImagenProduct.Name = "pbxImagenProduct";
            this.pbxImagenProduct.Size = new System.Drawing.Size(200, 150);
            this.pbxImagenProduct.TabIndex = 26;
            this.pbxImagenProduct.TabStop = false;
            // 
            // FormAgregarEditarProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 320);
            this.Controls.Add(this.pbxImagenProduct);
            this.Controls.Add(this.lblAlternativeBarcode);
            this.Controls.Add(this.btnSelecionarImagen);
            this.Controls.Add(this.ckbState);
            this.Controls.Add(this.btnGuardarEditar);
            this.Controls.Add(this.lblSalePercentage);
            this.Controls.Add(this.txtSalePercentage);
            this.Controls.Add(this.lblPriceBuy);
            this.Controls.Add(this.txtPriceBuy);
            this.Controls.Add(this.lblBarcode);
            this.Controls.Add(this.txtBarcode);
            this.Controls.Add(this.lblProductCode);
            this.Controls.Add(this.txtProductCode);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblMark);
            this.Controls.Add(this.cbxMark);
            this.Controls.Add(this.lblSubCategory);
            this.Controls.Add(this.cbxSubCategory);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.cbxCategory);
            this.Controls.Add(this.lblUnitMeasure);
            this.Controls.Add(this.cbxUnitMeasure);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAgregarEditarProducto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormAgregarProducto";
            this.Load += new System.EventHandler(this.FormAgregarProducto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxImagenProduct)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox cbxUnitMeasure;
        private Label lblUnitMeasure;
        private Label lblCategory;
        private ComboBox cbxCategory;
        private Label lblSubCategory;
        private ComboBox cbxSubCategory;
        private Label lblMark;
        private ComboBox cbxMark;
        private TextBox txtName;
        private Label lblName;
        private Label lblDescription;
        private TextBox txtDescription;
        private Label lblProductCode;
        private TextBox txtProductCode;
        private Label lblBarcode;
        private TextBox txtBarcode;
        private Label lblPriceBuy;
        private TextBox txtPriceBuy;
        private Label lblSalePercentage;
        private TextBox txtSalePercentage;
        private Button btnGuardarEditar;
        private CheckBox ckbState;
        private Button btnSelecionarImagen;
        private OpenFileDialog openFileDialog1;
        private Label lblAlternativeBarcode;
        private PictureBox pbxImagenProduct;
    }
}