﻿namespace Desk_BusinessAdminCJS.View.Categorys
{
    partial class FormListaCategoryYSubCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormListaCategoryYSubCategory));
            this.btnNuevaCategoria = new System.Windows.Forms.Button();
            this.gbxCategory = new System.Windows.Forms.GroupBox();
            this.btnBuscarCategory = new System.Windows.Forms.Button();
            this.txtBuscarCategory = new System.Windows.Forms.TextBox();
            this.dgvListCategory = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnBuscarSubCategory = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.txtBuscarSubCategory = new System.Windows.Forms.TextBox();
            this.dgvListSubCategory = new System.Windows.Forms.DataGridView();
            this.gbxCategory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListCategory)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListSubCategory)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNuevaCategoria
            // 
            this.btnNuevaCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNuevaCategoria.Location = new System.Drawing.Point(765, 22);
            this.btnNuevaCategoria.Margin = new System.Windows.Forms.Padding(4);
            this.btnNuevaCategoria.Name = "btnNuevaCategoria";
            this.btnNuevaCategoria.Size = new System.Drawing.Size(91, 28);
            this.btnNuevaCategoria.TabIndex = 19;
            this.btnNuevaCategoria.Text = "Categoría";
            this.btnNuevaCategoria.UseVisualStyleBackColor = true;
            this.btnNuevaCategoria.Click += new System.EventHandler(this.btnNuevaCategoria_Click);
            // 
            // gbxCategory
            // 
            this.gbxCategory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxCategory.Controls.Add(this.btnBuscarCategory);
            this.gbxCategory.Controls.Add(this.txtBuscarCategory);
            this.gbxCategory.Controls.Add(this.btnNuevaCategoria);
            this.gbxCategory.Controls.Add(this.dgvListCategory);
            this.gbxCategory.Location = new System.Drawing.Point(12, 12);
            this.gbxCategory.Name = "gbxCategory";
            this.gbxCategory.Size = new System.Drawing.Size(863, 280);
            this.gbxCategory.TabIndex = 20;
            this.gbxCategory.TabStop = false;
            this.gbxCategory.Text = "Lista de Categoría";
            // 
            // btnBuscarCategory
            // 
            this.btnBuscarCategory.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBuscarCategory.Location = new System.Drawing.Point(362, 25);
            this.btnBuscarCategory.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscarCategory.Name = "btnBuscarCategory";
            this.btnBuscarCategory.Size = new System.Drawing.Size(73, 28);
            this.btnBuscarCategory.TabIndex = 18;
            this.btnBuscarCategory.Text = "Buscar";
            this.btnBuscarCategory.UseVisualStyleBackColor = true;
            // 
            // txtBuscarCategory
            // 
            this.txtBuscarCategory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.txtBuscarCategory.Location = new System.Drawing.Point(7, 25);
            this.txtBuscarCategory.Margin = new System.Windows.Forms.Padding(4);
            this.txtBuscarCategory.Name = "txtBuscarCategory";
            this.txtBuscarCategory.Size = new System.Drawing.Size(346, 25);
            this.txtBuscarCategory.TabIndex = 17;
            this.txtBuscarCategory.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBuscarCategory_KeyUp);
            // 
            // dgvListCategory
            // 
            this.dgvListCategory.AllowUserToAddRows = false;
            this.dgvListCategory.AllowUserToDeleteRows = false;
            this.dgvListCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvListCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListCategory.Location = new System.Drawing.Point(7, 61);
            this.dgvListCategory.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListCategory.Name = "dgvListCategory";
            this.dgvListCategory.ReadOnly = true;
            this.dgvListCategory.RowTemplate.Height = 25;
            this.dgvListCategory.Size = new System.Drawing.Size(849, 212);
            this.dgvListCategory.TabIndex = 14;
            this.dgvListCategory.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListCategory_CellContentClick);
            this.dgvListCategory.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvListCategory_CellMouseMove);
            this.dgvListCategory.SelectionChanged += new System.EventHandler(this.dgvListCategory_SelectionChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.btnBuscarSubCategory);
            this.groupBox2.Controls.Add(this.btnNuevo);
            this.groupBox2.Controls.Add(this.txtBuscarSubCategory);
            this.groupBox2.Controls.Add(this.dgvListSubCategory);
            this.groupBox2.Location = new System.Drawing.Point(12, 298);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(863, 280);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Lista de SubCategoría";
            // 
            // btnBuscarSubCategory
            // 
            this.btnBuscarSubCategory.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBuscarSubCategory.Location = new System.Drawing.Point(362, 22);
            this.btnBuscarSubCategory.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscarSubCategory.Name = "btnBuscarSubCategory";
            this.btnBuscarSubCategory.Size = new System.Drawing.Size(73, 28);
            this.btnBuscarSubCategory.TabIndex = 21;
            this.btnBuscarSubCategory.Text = "Buscar";
            this.btnBuscarSubCategory.UseVisualStyleBackColor = true;
            // 
            // btnNuevo
            // 
            this.btnNuevo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNuevo.Location = new System.Drawing.Point(739, 20);
            this.btnNuevo.Margin = new System.Windows.Forms.Padding(4);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(117, 28);
            this.btnNuevo.TabIndex = 18;
            this.btnNuevo.Text = "SubCategoría";
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // txtBuscarSubCategory
            // 
            this.txtBuscarSubCategory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.txtBuscarSubCategory.Location = new System.Drawing.Point(6, 22);
            this.txtBuscarSubCategory.Margin = new System.Windows.Forms.Padding(4);
            this.txtBuscarSubCategory.Name = "txtBuscarSubCategory";
            this.txtBuscarSubCategory.Size = new System.Drawing.Size(346, 25);
            this.txtBuscarSubCategory.TabIndex = 20;
            this.txtBuscarSubCategory.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBuscarSubCategory_KeyUp);
            // 
            // dgvListSubCategory
            // 
            this.dgvListSubCategory.AllowUserToAddRows = false;
            this.dgvListSubCategory.AllowUserToDeleteRows = false;
            this.dgvListSubCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvListSubCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListSubCategory.Location = new System.Drawing.Point(7, 56);
            this.dgvListSubCategory.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListSubCategory.Name = "dgvListSubCategory";
            this.dgvListSubCategory.ReadOnly = true;
            this.dgvListSubCategory.RowTemplate.Height = 25;
            this.dgvListSubCategory.Size = new System.Drawing.Size(849, 217);
            this.dgvListSubCategory.TabIndex = 14;
            this.dgvListSubCategory.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListSubCategory_CellContentClick);
            this.dgvListSubCategory.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvListSubCategory_CellMouseMove);
            // 
            // FormListaCategoryYSubCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 589);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gbxCategory);
            this.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormListaCategoryYSubCategory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Lista de Categoria Y SubCategoria";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormListaCategoryYSubCategory_Load);
            this.gbxCategory.ResumeLayout(false);
            this.gbxCategory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListCategory)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListSubCategory)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Button btnNuevaCategoria;
        private GroupBox gbxCategory;
        private DataGridView dgvListCategory;
        private GroupBox groupBox2;
        private DataGridView dgvListSubCategory;
        private Button btnBuscarCategory;
        private TextBox txtBuscarCategory;
        private Button btnBuscarSubCategory;
        private Button btnNuevo;
        private TextBox txtBuscarSubCategory;
    }
}