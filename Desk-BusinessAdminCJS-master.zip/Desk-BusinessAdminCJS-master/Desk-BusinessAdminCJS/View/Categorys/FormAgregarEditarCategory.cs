﻿using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;

namespace Desk_BusinessAdminCJS.View.Categorys
{
    public partial class FormAgregarEditarCategory : Form
    {
        public Category _category;
        public Helper _helper;
        public DataContext _dataContext;
        public bool _Agregar; 

        public FormAgregarEditarCategory(Category category, bool agregar)
        {
            InitializeComponent();
            _dataContext = new DataContext();
            _category = category;
            _helper = new Helper();
            _Agregar = agregar;
        }

        private void FormAgregarEditarCategory_Load(object sender, EventArgs e)
        {
            try
            {
                if (!_Agregar && _category != null)
                {
                    if (_category.Id < 1)
                        throw new Exception("Por favor enviar la información a editar.");

                    txtCodigo.Text = _category.CategoryCode;
                    txtDescripcion.Text = _category.Description;
                    txtNombre.Text = _category.Name;
                    cbxState.Text = _category.State ? "Desactivar" : "Activar";
                    cbxState.Checked = _category.State;
                    cbxState.Visible = true;
                    Application.DoEvents();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al iniciar el modulo de Categoria", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAgregarEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (_Agregar)
                    _category = new Category();

                _category.Name = txtNombre.Text;
                _category.Description = txtDescripcion.Text;
                _category.CategoryCode = txtCodigo.Text.PadLeft(4, '0');

                if (_helper.ValidarObjecto(_category))
                {
                    _category.DateUpdate = DateTime.Now;
                    _category.CreationDate = _Agregar ? DateTime.Now : _category.CreationDate;
                    _category.State = _Agregar ? true : cbxState.Checked;

                    if (_Agregar)
                        _dataContext.Add(_category);
                    else
                        _dataContext.Entry(_category).State = EntityState.Modified;

                    _dataContext.SaveChanges();
                }
                string strAccion = _Agregar ? "Agregado" : "Actualizado";
                string strTitulo = $"Categoria {strAccion} con exito.";
                string strMensaje = $"Se creo la Categoria:{Environment.NewLine}{Environment.NewLine}" +
                                    $"Código: {_category.CategoryCode}{Environment.NewLine}" +
                                    $"Nombre: {_category.Name}{Environment.NewLine}" +
                                    $"Descripción: {_category.Description}{Environment.NewLine}";
                MessageBox.Show(strMensaje, strTitulo, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.Close();
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                    if (ex.InnerException.Message.Contains("UNIQUE constraint failed"))
                    {
                        MessageBox.Show($"El codigo {_category.CategoryCode} ya existe, por favor validar", "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                MessageBox.Show(ex.Message, "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsDigit(e.KeyChar) && !(e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Delete))
                    e.Handled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al ingresar el código", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbxState_Click(object sender, EventArgs e)
        {
            if (cbxState.Checked)
                cbxState.Text = "Desactivar";
            else
                cbxState.Text = "Activar";
        }
    }
}
