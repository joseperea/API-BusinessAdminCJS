﻿using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using Desk_BusinessAdminCJS.DataView;
using System.Runtime.CompilerServices;
using Desk_BusinessAdminCJS.View.Marks;

namespace Desk_BusinessAdminCJS.View.Categorys
{
    public partial class FormListaCategoryYSubCategory : Form
    {
        private DataContext _dataContext;
        private Helper _helper;
        private List<Category> _category;
        private List<SubCategory> _subCategory;
        private List<CategoryYSubCategory> _CategoryYSubCategory;

        public FormListaCategoryYSubCategory()
        {
            InitializeComponent();
            _dataContext = new DataContext();
            _helper = new Helper();
        }

        private async void FormListaCategoryYSubCategory_Load(object sender, EventArgs e)
        {
            try
            {

                cargarCategoriaYSubCategoria();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al iniciar el modulo de lista de marcas");
            }
        }

        private async void cargarCategoriaYSubCategoria()
        {
            try
            {
                dgvListCategory.Rows.Clear();
                dgvListSubCategory.Rows.Clear();

                _category = await _dataContext.Category.ToListAsync();
                _subCategory = await _dataContext.SubCategory.ToListAsync();

                if (_category.Count > 0)
                    dgvListCategory = _helper.loadListDataGrid(dgvListCategory, _category, false, true);
                if (_subCategory.Count > 0)
                    dgvListSubCategory = _helper.loadListDataGrid(dgvListSubCategory, _subCategory, false, true);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private DataGridView AddColumna(DataGridView dataGridView,string nombreColumna)
        {
            try
            {
                if (!string.IsNullOrEmpty(nombreColumna))
                {
                    if (!dataGridView.Columns.Contains(nombreColumna))
                    {
                        DataGridViewImageColumn img = new DataGridViewImageColumn();
                        //Image image = Image.FromFile(Path.Combine(_rutaInicioAplicacion, "Resources", "edit.png"));
                        img.Image = Properties.Resources.edit;
                        img.HeaderText = nombreColumna;
                        img.Name = nombreColumna;
                        img.ToolTipText = nombreColumna;
                        dataGridView.Columns.Add(img);
                    }
                }

                return dataGridView;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnNuevaCategoria_Click(object sender, EventArgs e)
        {
            try
            {
                FormAgregarEditarCategory formAgregarEditarCategory = new FormAgregarEditarCategory(new Category(), true);
                formAgregarEditarCategory.ShowDialog();
                dgvListCategory.Rows.Clear();
                cargarCategoriaYSubCategoria();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al agregar una nueva Categoria", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void txtBuscarCategory_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                _category = await _dataContext.Category.ToListAsync();

                if (_category.Count > 0)
                {
                    _category = _category.Where(t => t.Name.ToLower().Contains(txtBuscarCategory.Text.ToLower()) || t.Description.ToLower().Contains(txtBuscarCategory.Text.ToLower()) || t.CategoryCode.Contains(txtBuscarCategory.Text)).ToList();
                    dgvListCategory.Rows.Clear();
                    dgvListCategory = _helper.loadListDataGrid(dgvListCategory, _category, false, true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro al buscar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void txtBuscarSubCategory_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                _subCategory = await _dataContext.SubCategory.ToListAsync();

                if (_subCategory.Count > 0)
                {
                    _subCategory = _subCategory.Where(t => t.Name.ToLower().Contains(txtBuscarSubCategory.Text.ToLower()) || t.Description.ToLower().Contains(txtBuscarSubCategory.Text.ToLower()) || t.SubCategoryCode.Contains(txtBuscarSubCategory.Text) || t.AlternativeBarcode.Contains(txtBuscarSubCategory.Text) || t.Categori.ToLower().Contains(txtBuscarSubCategory.Text.ToLower())).ToList();
                    dgvListSubCategory.Rows.Clear();
                    dgvListSubCategory = _helper.loadListDataGrid(dgvListSubCategory, _subCategory, false, true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro al buscar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            try
            {
                FormAgregarEditarSubCategorics formAgregarEditarSubCategorics = new FormAgregarEditarSubCategorics(new SubCategory(), true);
                formAgregarEditarSubCategorics.ShowDialog();
                dgvListSubCategory.Rows.Clear();
                cargarCategoriaYSubCategoria();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al agregar una nueva Categoria", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvListCategory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0)
                {
                    _dataContext = new DataContext();
                    if (new string[] { "Editar" }.Any(t => t == dgvListCategory.Columns[e.ColumnIndex].Name))
                    {
                        DataGridViewRow dataGridViewRowCollection = dgvListCategory.Rows[e.RowIndex];
                        Category category = _helper.MapearDataGridRowObjeto(new Category(), dataGridViewRowCollection);
                        FormAgregarEditarCategory formAgregarEditarCategory = new FormAgregarEditarCategory(category, false);
                        formAgregarEditarCategory.ShowDialog();
                        cargarCategoriaYSubCategoria();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al editar o eliminar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvListSubCategory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0)
                {
                    _dataContext = new DataContext();
                    if (new string[] { "Editar" }.Any(t => t == dgvListSubCategory.Columns[e.ColumnIndex].Name))
                    {
                        DataGridViewRow dataGridViewRowCollection = dgvListSubCategory.Rows[e.RowIndex];
                        SubCategory subCategory = _helper.MapearDataGridRowObjeto(new SubCategory(), dataGridViewRowCollection);
                        FormAgregarEditarSubCategorics formAgregarEditarSubCategorics = new FormAgregarEditarSubCategorics(subCategory, false);
                        formAgregarEditarSubCategorics.ShowDialog();
                        dgvListSubCategory.Rows.Clear();
                        cargarCategoriaYSubCategoria();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al editar o eliminar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvListCategory_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex >= 0)
            {
                if (new string[] { "Editar", "Eliminar" }.Any(t => dgvListCategory.Columns[e.ColumnIndex].Name.ToLower().Contains(t.ToLower())))
                    dgvListCategory.Cursor = Cursors.Hand;
                else
                    dgvListCategory.Cursor = Cursors.Default;
            }
            else
                dgvListCategory.Cursor = Cursors.Default;
        }

        private void dgvListSubCategory_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex >= 0)
            {
                if (new string[] { "Editar", "Eliminar" }.Any(t => dgvListSubCategory.Columns[e.ColumnIndex].Name.ToLower().Contains(t.ToLower())))
                    dgvListSubCategory.Cursor = Cursors.Hand;
                else
                    dgvListSubCategory.Cursor = Cursors.Default;
            }
            else
                dgvListSubCategory.Cursor = Cursors.Default;
        }

        private void dgvListCategory_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgvListCategory.SelectedRows.Count > 0)
                {
                    DataGridViewRow dataGridViewRowCollection = dgvListCategory.Rows[dgvListCategory.CurrentRow.Index];
                    Category category = _helper.MapearDataGridRowObjeto(new Category(), dataGridViewRowCollection);

                    List<SubCategory> subCategories = _subCategory.Where(t => t.CategoryId == category.Id).OrderByDescending(t => t.SubCategoryCode).ThenByDescending(t => t.Name).ToList();

                    if (subCategories.Count < 1)
                        return;

                    subCategories.ForEach(t => _subCategory.Remove(t));
                    subCategories.ForEach(t => _subCategory.Insert(0,t));

                    dgvListSubCategory.Rows.Clear();
                    dgvListSubCategory = _helper.loadListDataGrid(dgvListSubCategory, _subCategory, false, true);

                }

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
