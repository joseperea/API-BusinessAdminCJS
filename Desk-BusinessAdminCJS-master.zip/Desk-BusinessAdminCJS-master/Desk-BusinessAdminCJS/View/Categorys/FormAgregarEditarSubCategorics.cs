﻿using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;

namespace Desk_BusinessAdminCJS.View.Categorys
{
    public partial class FormAgregarEditarSubCategorics : Form
    {
        public SubCategory _subCategory;
        public Helper _helper;
        public DataContext _dataContext;
        public List<Category> _categories;
        public bool _Agregar;

        public FormAgregarEditarSubCategorics(SubCategory subCategory, bool agregar)
        {
            InitializeComponent();
            _dataContext = new DataContext();
            _subCategory = subCategory;
            _helper = new Helper();
            _Agregar = agregar;
        }

        private async void FormAgregarEditarSubCategorics_Load(object sender, EventArgs e)
        {
            try
            {
                _categories = await _dataContext.Category.ToListAsync();
                if (_categories.Count > 0) 
                {
                    
                    cbxCategory = _helper.loadListComboBox(cbxCategory, _categories, "Categoría", true);
                    cbxCategory.SelectedIndex = -1;
                }

                if (!_Agregar && _subCategory != null)
                {
                    if (_subCategory.Id < 1)
                        throw new Exception("Por favor enviar la información a editar.");

                    txtCodigo.Text = _subCategory.SubCategoryCode;
                    txtDescripcion.Text = _subCategory.Description;
                    txtNombre.Text = _subCategory.Name;
                    cbxState.Text = _subCategory.State ? "Desactivar" : "Activar";
                    cbxState.Checked = _subCategory.State;
                    cbxState.Visible = true;
                    cbxCategory.SelectedValue = _subCategory.CategoryId;
                    Application.DoEvents();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al iniciar el modulo de SubCategoria", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAgregarEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (_Agregar)
                    _subCategory = new SubCategory();

                _subCategory.Name = txtNombre.Text;
                _subCategory.Description = txtDescripcion.Text;
                _subCategory.SubCategoryCode = txtCodigo.Text.PadLeft(4, '0');
                if (cbxCategory.SelectedIndex > -1)
                {
                    _subCategory.CategoryId = Convert.ToInt32(cbxCategory.SelectedValue);
                    _subCategory.Category = _Agregar ? _subCategory.Category : _categories.Find(t => t.Id ==_subCategory.CategoryId);
                }

                if (_helper.ValidarObjecto(_subCategory))
                {
                    _subCategory.DateUpdate = DateTime.Now;
                    _subCategory.CreationDate = _Agregar ? DateTime.Now : _subCategory.CreationDate;
                    _subCategory.State = _Agregar ? true : cbxState.Checked;

                    if (_Agregar) 
                    {
                        _dataContext.Add(_subCategory);
                        _subCategory.Category = _categories.Find(t => t.Id == _subCategory.CategoryId);
                    }
                    else
                        _dataContext.Entry(_subCategory).State = EntityState.Modified;

                    _dataContext.SaveChanges();
                }
                string strAccion = _Agregar ? "Agregada" : "Actualizada";
                string strTitulo = $"Categoria {strAccion} con exito.";
                string strMensaje = $"Se creo la Categoria:{Environment.NewLine}{Environment.NewLine}" +
                                    $"Categoria: {_subCategory.Category.Name}{Environment.NewLine}" +
                                    $"Código: {_subCategory.SubCategoryCode}{Environment.NewLine}" +
                                    $"Nombre: {_subCategory.Name}{Environment.NewLine}" +
                                    $"Descripción: {_subCategory.Description}{Environment.NewLine}";
                MessageBox.Show(strMensaje, strTitulo, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.Close();
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                    if (ex.InnerException.Message.Contains("UNIQUE constraint failed"))
                    {
                        MessageBox.Show($"El codigo {_subCategory.SubCategoryCode} ya existe, por favor validar", "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                MessageBox.Show(ex.Message, "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbxState_Click(object sender, EventArgs e)
        {
            if (cbxState.Checked)
                cbxState.Text = "Desactivar";
            else
                cbxState.Text = "Activar";
        }
    }
}
