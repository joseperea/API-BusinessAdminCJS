﻿using Desk_BusinessAdminCJS.Data;
using Desk_BusinessAdminCJS.Data.Entities;
using Desk_BusinessAdminCJS.View.Categorys;
using Desk_BusinessAdminCJS.View.Marks;
using Desk_BusinessAdminCJS.View.Product;
using Desk_BusinessAdminCJS.View.UnitMeasures;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desk_BusinessAdminCJS.View
{
    public partial class FormPrincipal : Form
    {
        public Form formHIjo;
        public Form formHIjoDialogo;
        public DataContext _dataContext;

        public FormPrincipal()
        {
            InitializeComponent();
            _dataContext = new DataContext();
        }

        private void productoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListProduct ltsproduct = new FormListProduct();
            showFrom(ltsproduct);
            
        }

        public void showFrom(Form form)
        {
            if (formHIjo != null)
                formHIjo.Close();

            formHIjo = form;
            formHIjo.MdiParent = this;
            formHIjo.Show();
        }

        public void showDialogoFrom(Form form)
        {
            if (formHIjoDialogo != null)
                formHIjoDialogo.Close();

            formHIjoDialogo = form;
            //formHIjoDialogo.MdiParent = this;
            formHIjoDialogo.ShowDialog();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            try
            {

                var bounds = Screen.FromControl(this).Bounds;
                this.Width = bounds.Width;
                this.Height = bounds.Height - 30;
                this.Location = new Point(bounds.X, bounds.Y);

                //_rutaInicioAplicacion = Path.Combine(Assembly.GetExecutingAssembly().Location);
                Helpers.Helper._rutaInicioAplicacion = AppDomain.CurrentDomain.BaseDirectory;
                Helpers.Helper._rutaInicioAplicacion = Helpers.Helper._rutaInicioAplicacion.Replace("net6.0-windows\\", string.Empty);
                Helpers.Helper._rutaInicioAplicacion = Helpers.Helper._rutaInicioAplicacion.Replace("bin\\Debug\\", string.Empty);

                CrearCarpetas(Helpers.Helper._rutaInicioAplicacion);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errar al iniciar la aplicacion.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                Application.Exit();
            }
        }

        private async void CrearCarpetas(string rutaInicioAplicacion)
        {
            try
            {
                if (!Directory.Exists(rutaInicioAplicacion))
                    Directory.CreateDirectory(rutaInicioAplicacion);

                rutaInicioAplicacion = Path.Combine(rutaInicioAplicacion, "Imagenes", "Products");

                if (!Directory.Exists(rutaInicioAplicacion))
                    Directory.CreateDirectory(rutaInicioAplicacion);

                foreach (var item in await _dataContext.SubCategory.ToListAsync())
                {
                    if (item.Category == null)
                        item.Category = await _dataContext.Category.FindAsync( item.CategoryId);

                    string strNuevaRuta = Path.Combine(rutaInicioAplicacion, $"{item.Category.Name.Trim()} ({item.Category.CategoryCode})", $"{item.Name.Trim()} ({item.SubCategoryCode})");

                    if (!Directory.Exists(strNuevaRuta))
                        Directory.CreateDirectory(strNuevaRuta);
                }
                
            }
            catch (Exception ex)
            {
               throw new Exception(ex.Message, ex);
            }
        }

        private void listaDeProductosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListProduct ltsproduct = new FormListProduct();
            showFrom(ltsproduct);
        }

        private void nuevaUnidadMedidasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAgregarEditarUnidadMedida formAgregarUnidadMedida = new FormAgregarEditarUnidadMedida(null, true);
            showDialogoFrom(formAgregarUnidadMedida);
        }

        private void listaUnidadMedidasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormlistaUnidadMedida formlistaUnidadMedida = new FormlistaUnidadMedida();
            showFrom(formlistaUnidadMedida);
        }

        private void unidadMedidasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormlistaUnidadMedida formlistaUnidadMedida = new FormlistaUnidadMedida();
            showFrom(formlistaUnidadMedida);
        }

        private void marcasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListaMark formListaMark = new FormListaMark();
            showFrom(formListaMark);
        }

        private void nuevaMarcaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAgargeEditarMark formListaMark = new FormAgargeEditarMark(null, true);
            showDialogoFrom(formListaMark);
        }

        private void listaMarcasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListaMark formListaMark = new FormListaMark();
            showFrom(formListaMark);
        }

        private void nuevaCategotiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAgregarEditarCategory formAgregarEditarCategory = new FormAgregarEditarCategory(null, true);
            showDialogoFrom(formAgregarEditarCategory);
        }

        private void nuevaSubCategoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAgregarEditarSubCategorics formAgregarEditarSubCategorics = new FormAgregarEditarSubCategorics(null, true);
            showDialogoFrom(formAgregarEditarSubCategorics);
        }

        private void categoriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListaCategoryYSubCategory formListaCategoryYSubCategory = new FormListaCategoryYSubCategory();
            showFrom(formListaCategoryYSubCategory);
        }

        private void listaCategotiaYSubCategoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListaCategoryYSubCategory formListaCategoryYSubCategory = new FormListaCategoryYSubCategory();
            showFrom(formListaCategoryYSubCategory);
        }

        private void nuevoProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAgregarEditarProducto product = new FormAgregarEditarProducto(new Data.Entities.Product(), true);
            showDialogoFrom(product);
        }
    }
}
