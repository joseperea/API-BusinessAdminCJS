﻿namespace Desk_BusinessAdminCJS.View
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.inventarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unidadMedidasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevaUnidadMedidasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaUnidadMedidasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marcasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevaMarcaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaMarcasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoriasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevaCategotiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevaSubCategoriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaCategotiaYSubCategoriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevoProductoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaDeProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proveedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevoProveedorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaProveedorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inventarioToolStripMenuItem,
            this.proveedoresToolStripMenuItem,
            this.ventasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(126, 450);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip";
            // 
            // inventarioToolStripMenuItem
            // 
            this.inventarioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unidadMedidasToolStripMenuItem,
            this.marcasToolStripMenuItem,
            this.categoriasToolStripMenuItem,
            this.productoToolStripMenuItem});
            this.inventarioToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.inventory_16;
            this.inventarioToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.inventarioToolStripMenuItem.Name = "inventarioToolStripMenuItem";
            this.inventarioToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.inventarioToolStripMenuItem.Text = "Inventario";
            this.inventarioToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // unidadMedidasToolStripMenuItem
            // 
            this.unidadMedidasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevaUnidadMedidasToolStripMenuItem,
            this.listaUnidadMedidasToolStripMenuItem});
            this.unidadMedidasToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.weight_16;
            this.unidadMedidasToolStripMenuItem.Name = "unidadMedidasToolStripMenuItem";
            this.unidadMedidasToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.unidadMedidasToolStripMenuItem.Text = "Unidad Medidas";
            this.unidadMedidasToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.unidadMedidasToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.unidadMedidasToolStripMenuItem.Click += new System.EventHandler(this.unidadMedidasToolStripMenuItem_Click);
            // 
            // nuevaUnidadMedidasToolStripMenuItem
            // 
            this.nuevaUnidadMedidasToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.add_16;
            this.nuevaUnidadMedidasToolStripMenuItem.Name = "nuevaUnidadMedidasToolStripMenuItem";
            this.nuevaUnidadMedidasToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.nuevaUnidadMedidasToolStripMenuItem.Text = "Nueva Unidad Medidas";
            this.nuevaUnidadMedidasToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nuevaUnidadMedidasToolStripMenuItem.Click += new System.EventHandler(this.nuevaUnidadMedidasToolStripMenuItem_Click);
            // 
            // listaUnidadMedidasToolStripMenuItem
            // 
            this.listaUnidadMedidasToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.checklist_16;
            this.listaUnidadMedidasToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.listaUnidadMedidasToolStripMenuItem.Name = "listaUnidadMedidasToolStripMenuItem";
            this.listaUnidadMedidasToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.listaUnidadMedidasToolStripMenuItem.Text = "Lista Unidad Medidas";
            this.listaUnidadMedidasToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.listaUnidadMedidasToolStripMenuItem.Click += new System.EventHandler(this.listaUnidadMedidasToolStripMenuItem_Click);
            // 
            // marcasToolStripMenuItem
            // 
            this.marcasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevaMarcaToolStripMenuItem,
            this.listaMarcasToolStripMenuItem});
            this.marcasToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.m_16;
            this.marcasToolStripMenuItem.Name = "marcasToolStripMenuItem";
            this.marcasToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.marcasToolStripMenuItem.Text = "Marcas";
            this.marcasToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.marcasToolStripMenuItem.Click += new System.EventHandler(this.marcasToolStripMenuItem_Click);
            // 
            // nuevaMarcaToolStripMenuItem
            // 
            this.nuevaMarcaToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.add_16;
            this.nuevaMarcaToolStripMenuItem.Name = "nuevaMarcaToolStripMenuItem";
            this.nuevaMarcaToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.nuevaMarcaToolStripMenuItem.Text = "Nueva Marca";
            this.nuevaMarcaToolStripMenuItem.Click += new System.EventHandler(this.nuevaMarcaToolStripMenuItem_Click);
            // 
            // listaMarcasToolStripMenuItem
            // 
            this.listaMarcasToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.checklist_16;
            this.listaMarcasToolStripMenuItem.Name = "listaMarcasToolStripMenuItem";
            this.listaMarcasToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.listaMarcasToolStripMenuItem.Text = "Lista Marcas";
            this.listaMarcasToolStripMenuItem.Click += new System.EventHandler(this.listaMarcasToolStripMenuItem_Click);
            // 
            // categoriasToolStripMenuItem
            // 
            this.categoriasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevaCategotiaToolStripMenuItem,
            this.nuevaSubCategoriaToolStripMenuItem,
            this.listaCategotiaYSubCategoriaToolStripMenuItem});
            this.categoriasToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.maintenance_32;
            this.categoriasToolStripMenuItem.Name = "categoriasToolStripMenuItem";
            this.categoriasToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.categoriasToolStripMenuItem.Text = "Categorias";
            this.categoriasToolStripMenuItem.Click += new System.EventHandler(this.categoriasToolStripMenuItem_Click);
            // 
            // nuevaCategotiaToolStripMenuItem
            // 
            this.nuevaCategotiaToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.subfolder_16;
            this.nuevaCategotiaToolStripMenuItem.Name = "nuevaCategotiaToolStripMenuItem";
            this.nuevaCategotiaToolStripMenuItem.Size = new System.Drawing.Size(294, 22);
            this.nuevaCategotiaToolStripMenuItem.Text = "Nueva Categotía";
            this.nuevaCategotiaToolStripMenuItem.Click += new System.EventHandler(this.nuevaCategotiaToolStripMenuItem_Click);
            // 
            // nuevaSubCategoriaToolStripMenuItem
            // 
            this.nuevaSubCategoriaToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.data_classification_16;
            this.nuevaSubCategoriaToolStripMenuItem.Name = "nuevaSubCategoriaToolStripMenuItem";
            this.nuevaSubCategoriaToolStripMenuItem.Size = new System.Drawing.Size(294, 22);
            this.nuevaSubCategoriaToolStripMenuItem.Text = "Nueva SubCategoría";
            this.nuevaSubCategoriaToolStripMenuItem.Click += new System.EventHandler(this.nuevaSubCategoriaToolStripMenuItem_Click);
            // 
            // listaCategotiaYSubCategoriaToolStripMenuItem
            // 
            this.listaCategotiaYSubCategoriaToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.checklist_16;
            this.listaCategotiaYSubCategoriaToolStripMenuItem.Name = "listaCategotiaYSubCategoriaToolStripMenuItem";
            this.listaCategotiaYSubCategoriaToolStripMenuItem.Size = new System.Drawing.Size(294, 22);
            this.listaCategotiaYSubCategoriaToolStripMenuItem.Text = "Lista Categotía y SubCategoría";
            this.listaCategotiaYSubCategoriaToolStripMenuItem.Click += new System.EventHandler(this.listaCategotiaYSubCategoriaToolStripMenuItem_Click);
            // 
            // productoToolStripMenuItem
            // 
            this.productoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoProductoToolStripMenuItem,
            this.listaDeProductosToolStripMenuItem});
            this.productoToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.productos_16;
            this.productoToolStripMenuItem.Name = "productoToolStripMenuItem";
            this.productoToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.productoToolStripMenuItem.Text = "Productos";
            this.productoToolStripMenuItem.Click += new System.EventHandler(this.productoToolStripMenuItem_Click);
            // 
            // nuevoProductoToolStripMenuItem
            // 
            this.nuevoProductoToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.add_16;
            this.nuevoProductoToolStripMenuItem.Name = "nuevoProductoToolStripMenuItem";
            this.nuevoProductoToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.nuevoProductoToolStripMenuItem.Text = "Nuevo Producto";
            this.nuevoProductoToolStripMenuItem.Click += new System.EventHandler(this.nuevoProductoToolStripMenuItem_Click);
            // 
            // listaDeProductosToolStripMenuItem
            // 
            this.listaDeProductosToolStripMenuItem.Image = global::Desk_BusinessAdminCJS.Properties.Resources.checklist_16;
            this.listaDeProductosToolStripMenuItem.Name = "listaDeProductosToolStripMenuItem";
            this.listaDeProductosToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.listaDeProductosToolStripMenuItem.Text = "Lista de Productos";
            this.listaDeProductosToolStripMenuItem.Click += new System.EventHandler(this.listaDeProductosToolStripMenuItem_Click);
            // 
            // proveedoresToolStripMenuItem
            // 
            this.proveedoresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoProveedorToolStripMenuItem,
            this.listaProveedorToolStripMenuItem});
            this.proveedoresToolStripMenuItem.Name = "proveedoresToolStripMenuItem";
            this.proveedoresToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.proveedoresToolStripMenuItem.Text = "Proveedores";
            this.proveedoresToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.proveedoresToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            // 
            // nuevoProveedorToolStripMenuItem
            // 
            this.nuevoProveedorToolStripMenuItem.Name = "nuevoProveedorToolStripMenuItem";
            this.nuevoProveedorToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.nuevoProveedorToolStripMenuItem.Text = "Nuevo Proveedor";
            // 
            // listaProveedorToolStripMenuItem
            // 
            this.listaProveedorToolStripMenuItem.Name = "listaProveedorToolStripMenuItem";
            this.listaProveedorToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.listaProveedorToolStripMenuItem.Text = "Lista Proveedor";
            // 
            // ventasToolStripMenuItem
            // 
            this.ventasToolStripMenuItem.Name = "ventasToolStripMenuItem";
            this.ventasToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.ventasToolStripMenuItem.Text = "Ventas";
            this.ventasToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ventasToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "FormPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Principal";
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem inventarioToolStripMenuItem;
        private ToolStripMenuItem productoToolStripMenuItem;
        private ToolStripMenuItem categoriasToolStripMenuItem;
        private ToolStripMenuItem unidadMedidasToolStripMenuItem;
        private ToolStripMenuItem marcasToolStripMenuItem;
        private ToolStripMenuItem proveedoresToolStripMenuItem;
        private ToolStripMenuItem nuevaUnidadMedidasToolStripMenuItem;
        private ToolStripMenuItem listaUnidadMedidasToolStripMenuItem;
        private ToolStripMenuItem nuevaMarcaToolStripMenuItem;
        private ToolStripMenuItem listaMarcasToolStripMenuItem;
        private ToolStripMenuItem nuevaCategotiaToolStripMenuItem;
        private ToolStripMenuItem nuevaSubCategoriaToolStripMenuItem;
        private ToolStripMenuItem listaCategotiaYSubCategoriaToolStripMenuItem;
        private ToolStripMenuItem nuevoProductoToolStripMenuItem;
        private ToolStripMenuItem listaDeProductosToolStripMenuItem;
        private ToolStripMenuItem nuevoProveedorToolStripMenuItem;
        private ToolStripMenuItem listaProveedorToolStripMenuItem;
        private ToolStripMenuItem ventasToolStripMenuItem;
    }
}