﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DeskBusinessAdminCJS.Migrations
{
    /// <inheritdoc />
    public partial class m3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Category",
                type: "TEXT",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "INTEGER");

            migrationBuilder.CreateIndex(
                name: "IX_UnitMeasure_UnitMeasureCode",
                table: "UnitMeasure",
                column: "UnitMeasureCode",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_UnitMeasure_UnitMeasureCode",
                table: "UnitMeasure");

            migrationBuilder.AlterColumn<int>(
                name: "Name",
                table: "Category",
                type: "INTEGER",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "TEXT");
        }
    }
}
