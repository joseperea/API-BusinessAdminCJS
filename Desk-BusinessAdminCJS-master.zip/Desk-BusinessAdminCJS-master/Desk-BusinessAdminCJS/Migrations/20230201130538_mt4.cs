﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DeskBusinessAdminCJS.Migrations
{
    /// <inheritdoc />
    public partial class mt4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_SubCategory_SubCategoryCode",
                table: "SubCategory",
                column: "SubCategoryCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Mark_MarkCode",
                table: "Mark",
                column: "MarkCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Category_CategoryCode",
                table: "Category",
                column: "CategoryCode",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_SubCategory_SubCategoryCode",
                table: "SubCategory");

            migrationBuilder.DropIndex(
                name: "IX_Mark_MarkCode",
                table: "Mark");

            migrationBuilder.DropIndex(
                name: "IX_Category_CategoryCode",
                table: "Category");
        }
    }
}
